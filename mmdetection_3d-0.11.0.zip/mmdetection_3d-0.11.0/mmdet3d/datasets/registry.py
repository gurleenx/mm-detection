from mmcv.utils import Registry

OBJECTSAMPLERS = Registry('Object sampler')
